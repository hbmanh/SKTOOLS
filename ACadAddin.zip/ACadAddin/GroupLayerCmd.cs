﻿using System;
using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.DatabaseServices;
namespace ACadAddin
{
    public class GroupLayerCmd : IExtensionApplication
    {
        public void Initialize()
        {
            throw new NotImplementedException();
        }

        public void Terminate()
        {
            throw new NotImplementedException();
        }

        [CommandMethod("GROUPLAYER")]
        public static void GroupLayer()
        {
            Document doc = Application.DocumentManager.MdiActiveDocument;
            Editor ed = doc.Editor;

            Database db = doc.Database;
            Transaction trans = db.TransactionManager.StartTransaction();
            using (trans)
            {
                BlockTable bt = (BlockTable)trans.GetObject(db.BlockTableId, OpenMode.ForWrite);
                BlockTableRecord btr = (BlockTableRecord)trans.GetObject(bt[BlockTableRecord.ModelSpace], OpenMode.ForWrite);

                LinetypeTable ltt = (LinetypeTable)trans.GetObject(db.LinetypeTableId, OpenMode.ForWrite);
                LayerTable lt = (LayerTable)trans.GetObject(db.LayerTableId, OpenMode.ForWrite);

                //ltt.UpgradeOpen();
                TypedValue[] tv = new TypedValue[1];
                tv.SetValue(new TypedValue((int)DxfCode.Start, "Line"),0);
                SelectionFilter filter = new SelectionFilter(tv);
                PromptSelectionResult psr = ed.SelectAll(filter);
                foreach(SelectedObject so in psr.Value)
                {
                    Line line = (Line)trans.GetObject(so.ObjectId, OpenMode.ForWrite);
                    var layerName = line.Layer;
                    var color = line.Color;
                    var linetypeId = line.LinetypeId;
                    var lineWeight = line.LineWeight;

                    string newLayerName = $"{line.Linetype}_{line.LineWeight}_{line.Color}";
                    bool layerExist = false;
                    LayerTableRecord ltr = null;
                    foreach (var layerId in lt)
                    {
                        var layer = trans.GetObject(layerId, OpenMode.ForWrite) as LayerTableRecord;
                        if (layer.Name == newLayerName)
                        {
                            layerExist = true;
                            ltr = layer;
                            break;
                        }
                    }
                    if (layerExist == false)
                    {
                        ltr = new LayerTableRecord();
                        ltr.Name = newLayerName;
                        ltr.Color = color;
                        ltr.LineWeight = lineWeight;
                        ltr.LinetypeObjectId = linetypeId;
                        lt.UpgradeOpen();
                        ObjectId id = lt.Add(ltr);
                        trans.AddNewlyCreatedDBObject(ltr, true);
                    }
                }
                trans.Commit();
            }
        }
    }
}
